#pragma once
#include "TextureManager.h"

class Sprites {


};